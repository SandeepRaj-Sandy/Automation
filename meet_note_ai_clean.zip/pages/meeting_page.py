from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from configparser import ConfigParser

class MeetingPage:
    def __init__(self, driver):
        self.driver = driver
        self.wait = WebDriverWait(driver, 10)

    def add_meeting(self, config_path):
        config = ConfigParser()
        config.read(config_path)

        if 'details' not in config.sections():
            raise Exception("Section [details] not found in config file!")

        subject = config.get('details', 'meeting_subject')
        meeting_link = config.get('details', 'meeting_link')

        self.wait.until(EC.visibility_of_element_located((By.XPATH, "//p[text()='Add to Meeting']"))).click()

        subject_input = self.wait.until(EC.presence_of_element_located((By.XPATH, "//input[@placeholder='Subject for the Meeting']")))
        subject_input.clear()
        subject_input.send_keys(subject)

        link_input = self.wait.until(EC.presence_of_element_located((By.XPATH, "//input[@placeholder='Enter Meeting Link']")))
        link_input.clear()
        link_input.send_keys(meeting_link)

        submit_btn = self.wait.until(EC.element_to_be_clickable((By.XPATH, "//button[@type='submit']")))
        submit_btn.click()
